export type ActionType = "REWARD" | "PENALIZE";
